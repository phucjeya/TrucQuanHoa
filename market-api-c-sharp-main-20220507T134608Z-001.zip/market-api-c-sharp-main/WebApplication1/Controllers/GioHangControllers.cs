﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MarketAPI.Entity;
using MarketAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Web.Http.Cors;

namespace MarketAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GioHangController : ControllerBase
    {
        private readonly ModelContext _context;
        public GioHangController(ModelContext context)
        {
            _context = context;
        }
        // GET: api/giohang/id
        [HttpGet("{id}")]
        public IEnumerable<GioHang> Get(string id)
        {
            return _context.GioHang.Where(kh => kh.makhachhang == id);
        }

        //GET api/giohangbygianhang
        [HttpGet("giohangbygianhang")]
        public IEnumerable<SanPham> GetTopSanPham(string id)
        {
            string query = "select top 5 TenSanPham " +
                "from DONHANG dh join CHITIETDONHANG ct on dh.MaDonHang = ct.MaDonHang " +
                "join sanpham s on ct.MaSanPham = s.MaSanPham " +
                "join GIANHANG g on g.MaGianHang = s.GianHang" +
                "where g.MaGianHang = 'GH0858'" +
                "group by TenSanPham" +
                "order by sum(ct.DonGia)";
            return _context.SanPham.FromSql(query).ToList();
        }

        // POST api/donhang
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [HttpPost]
        public void Post([FromBody] GioHang giohang)
        {
            _context.GioHang.Add(giohang);
            _context.SaveChanges();
        }
    }
}